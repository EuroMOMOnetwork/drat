.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: MOMO')
  packageStartupMessage('Version')
}
