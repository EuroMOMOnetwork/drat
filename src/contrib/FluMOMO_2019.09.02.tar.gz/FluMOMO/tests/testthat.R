library(testthat)
library(FluMOMO)
library(data.table)

test_check("FluMOMO")
