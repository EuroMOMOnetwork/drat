devtools::build(binary=F)
devtools::build(binary=T)

drat::insertPackage(
  file = "C:/Users/riwh/OneDrive - Folkehelseinstituttet/packages/MOMO_2020.4.17.tar.gz",
  repodir = "C:/Users/riwh/OneDrive - Folkehelseinstituttet/git/euromomonetwork/drat"
)

drat::insertPackage(
  file = "C:/Users/riwh/OneDrive - Folkehelseinstituttet/packages/MOMO_2020.4.17.zip",
  repodir = "C:/Users/riwh/OneDrive - Folkehelseinstituttet/git/euromomonetwork/drat"
)
