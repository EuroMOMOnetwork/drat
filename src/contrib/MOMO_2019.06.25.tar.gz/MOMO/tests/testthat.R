library(testthat)
library(MOMO)
library(data.table)

test_check("MOMO")
