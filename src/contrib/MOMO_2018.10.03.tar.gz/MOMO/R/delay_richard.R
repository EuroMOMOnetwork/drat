#' delayMOMO_richard
#' This is the package standardly used for Norway
#' @param aggr Output data from aggregateMOMO()
#' @param zvalue 95\% z-value
#' @import data.table
#' @importFrom stats glm poisson quasipoisson predict
delayMOMO_richard <- function(aggr, zvalue=1.96) {
  #aggr <- readRDS("test.RDS")
  aggrMaster <- copy(aggr)
  setDT(aggr)
  aggr <- aggr[order(aggr$wk),]

  #* Drop obs in week of aggregation
  aggr <- aggr[-nrow(aggr),]

  modellingWeeks <- momoAttr$PRWEEK:momoAttr$WEEK2
  modellingWeeks <- modellingWeeks[modellingWeeks > min(aggr$wk)+momoAttr$delayCorr*2]

  aggr$sin52 <- sin(aggr$WoDi*2*pi/52)
  aggr$cos52 <- cos(aggr$WoDi*2*pi/52)

  aggr$sin26 <- sin(aggr$WoDi*2*pi/26)
  aggr$cos26 <- cos(aggr$WoDi*2*pi/26)

  aggr[,diff_WR1_minus_WR0:=WR1-WR0]

  for(r in 0:(momoAttr$delayCorr*2)){
    aggr[,(sprintf("WR0_lag%s",r)):=shift(WR0,n=r)]
    aggr[,(sprintf("WR1_lag%s",r)):=shift(WR1,n=r)]
    aggr[,(sprintf("WR2_lag%s",r)):=shift(WR2,n=r)]

    aggr[,(sprintf("diff_WR1_minus_WR0_lag%s",r)):=shift(diff_WR1_minus_WR0,n=r)]
  }

  for(r in 0:momoAttr$delayCorr){
    form <- sprintf("nb2 ~ WR%s*as.factor(YoDi) + closed + sin52 + cos52", r)
    fit <- glm(as.formula(form), data=aggr[aggr$wk %in% modellingWeeks,], family=poisson)
    od <- max(1,sum(fit$weights * fit$residuals^2)/fit$df.r)
    if (od > 1) fit <- glm(as.formula(form),data=aggr[aggr$wk %in% modellingWeeks,], family=quasipoisson)

    summary(fit)
    p <- predict(fit,aggr)
    aggr[,(sprintf("pred%s",r)):=p]

    p <- predict(fit,aggr,se.fit=TRUE)$se.fit
    aggr[,(sprintf("stdp%s",r)):=p]

    # creating VpWRXX (theoretical)
    aggr[,(sprintf("VpWR%s",r)):=pmax(0,get(sprintf("pred%s",r))*od) + (get(sprintf("pred%s",r))*get(sprintf("stdp%s",r)))^2]

    UPIvar <- sprintf("UPI%s",r)
    LPIvar <- sprintf("LPI%s",r)

    UCIvar <- sprintf("UCI%s",r)
    LCIvar <- sprintf("LCI%s",r)

    aggr[,(UPIvar):=as.numeric(NA)]
    aggr[,(LPIvar):=as.numeric(NA)]

    aggr[,(UCIvar):=as.numeric(NA)]
    aggr[,(LCIvar):=as.numeric(NA)]

    # Prediction Interval
    aggr[,(UPIvar):=(get(sprintf("pred%s",r))^(2/3) + zvalue*((4/9)*(get(sprintf("pred%s",r))^(1/3))*(od+(get(sprintf("stdp%s",r))^2)*(get(sprintf("pred%s",r)))))^(1/2))^(3/2)]
    aggr[,(LPIvar):=(get(sprintf("pred%s",r))^(2/3) - zvalue*((4/9)*(get(sprintf("pred%s",r))^(1/3))*(od+(get(sprintf("stdp%s",r))^2)*(get(sprintf("pred%s",r)))))^(1/2))^(3/2)]

    aggr[,(UCIvar):=get(sprintf("pred%s",r)) + zvalue*get(sprintf("stdp%s",r))]
    aggr[,(LCIvar):=get(sprintf("pred%s",r)) - zvalue*get(sprintf("stdp%s",r))]
  }

  aggr[,VpWR:=0]
  aggr[,delay:=max(wk)-wk]
  for(r in 0:momoAttr$delayCorr){
    aggr[delay==r,VpWR:=get(sprintf("VpWR%s",r))]
    aggr[delay==r,pred:=get(sprintf("pred%s",r))]
    aggr[delay==r,UPIc:=get(sprintf("UPI%s",r))]
    aggr[delay==r,LPIc:=get(sprintf("LPI%s",r))]
    aggr[delay==r,UCIc:=get(sprintf("UCI%s",r))]
    aggr[delay==r,LCIc:=get(sprintf("LCI%s",r))]
  }
  #** we generate the CORRECTED number of death
  aggr[wk<=momoAttr$WEEK2,nbc:=nb]
  aggr[momoAttr$WEEK2 < wk & wk<= momoAttr$WEEK, nbc:=pmax(0,pred,nb)]

  aggr[,GROUP:=momoAttr$group]

  aggr <- as.data.frame(aggr)
  return(aggr)
}

